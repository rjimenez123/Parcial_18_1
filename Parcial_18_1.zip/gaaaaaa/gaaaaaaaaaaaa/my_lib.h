/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   my_lib.h
 * Author: alulab14
 *
 * Created on 11 de mayo de 2019, 10:52 AM
 */

#ifndef MY_LIB_H
#define MY_LIB_H

void leerUsuarios(int *&,char **& );
void imprimirUsuarios(int* , char **);

char* leeCad(char c);

void leerLbros(char***& libros, int**& stock);
void imprimirLibros(char*** libros,int** stock);
void incrementarEspacios(char***& libros, int**& stock, int& tamPointer, int& numLibros);

int* registrarPrestamos(int* codigoUs,char****& prestamos, char*** libros, int**& stock);
void imprimirPrestamos(int* codigoUs, char** nombresUs,char**** prestamos);
void imprimirLibros(char*** libros, int** stock);   
int buscaPeMascota(int* codigoUs, int codigoAlumno);
int buscaBienMascota(char*** libros, char* searchIt);
void asignaPrestamo(char***& source, char** aPrestium, int& tamanhitus, int& aCapacitam);
void incrementarEspacios(char***& , int& , int& );

#endif /* MY_LIB_H */
