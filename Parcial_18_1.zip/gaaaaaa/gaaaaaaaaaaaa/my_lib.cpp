/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   my_lib.cpp
 * Author: alulab14
 * 
 * Created on 11 de mayo de 2019, 10:52 AM
 */

#include "my_lib.h"
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <cctype>
#include <cstring>
#include <complex>

#define INCREMENTO 5

using namespace std;

void leerUsuarios(int *&codigoUs,char **& nombreUs) {
    int buffCodigo[500], numAlumnos = 0;
    char *buffNombre[500];
    
    while(1) {
        if (cin.peek() == '\n') break;
        cin >> buffCodigo[numAlumnos];
        cin.get();
        buffNombre[numAlumnos] = leeCad('\n');
        cin.get();
        numAlumnos++;
    }
    cin.get();
    
    codigoUs = new int[numAlumnos+1];
    nombreUs = new char*[numAlumnos+1];
    
    for (int i = 0; i < numAlumnos; i++) {
        codigoUs[i] = buffCodigo[i];
        nombreUs[i] = buffNombre[i];
    }
    
    codigoUs[numAlumnos] = -123;
    nombreUs[numAlumnos] = NULL; 
    
}

char* leeCad(char c) {
    char buff[100], *cad;
    int numChars = 0;
    
    while(1) {
        if (cin.peek() == c) break;
        buff[numChars] = cin.get();
        numChars++;
    }
    
    cad = new char[numChars+1];
    for (int i = 0; i < numChars; i++)
        cad[i] = buff[i];
    cad[numChars] = '\0';
    return cad;
}

void imprimirUsuarios(int* codigoUs, char **nombreUs) {
    cout << left << setw(10) << "CODIGO" << setw(30) << "NOMBRE DE LA MASCOTA" << endl;
    for (int i = 0; codigoUs[i] > 0; i++)
        cout << left << setw(10) << codigoUs[i] << setw(50) << nombreUs[i] << endl; 
} 

void leerLbros(char***& libros, int**& stock) {
    int tamPointer = 0, numLibros = 0;
    libros = NULL; stock = NULL;
    char *codigo, *nombreLibro, *nomAlumno;
    int stockDisp;
    
    while(1) {
        if (cin.peek() == '\n') break;
        
        if (tamPointer == numLibros) incrementarEspacios(libros, stock, tamPointer, numLibros);
        
        codigo = leeCad(',');
        cin.get();
        nombreLibro = leeCad(',');
        cin.get();
        nomAlumno = leeCad(',');
        cin.get(); 
        cin >> stockDisp;
        cin.get(); 
        
        char** libro = new char*[3];
        libro[0] = codigo;
        libro[1] = nombreLibro;
        libro[2] = nomAlumno;
        
        int* stockLibro = new int[2];
        stockLibro[0] = stockDisp;
        stockLibro[1] = stockDisp;
        
        stock[numLibros-1] = stockLibro;
        stock[numLibros] = NULL;
        
        libros[numLibros-1] = libro;
        libros[numLibros] = NULL;
        
        numLibros++;
    }
    cin.get();
}

void incrementarEspacios(char***& libros, int**& stock, int& tamPointer, int& numLibros) {
    char*** auxLibros;
    int** auxStock;
    tamPointer += INCREMENTO;
    if (libros == NULL) {
        libros = new char**[tamPointer];
        stock = new int*[tamPointer];
        libros[0] = NULL;
        stock[0] = NULL;
        numLibros++;
    } else {
        auxLibros = new char**[tamPointer];
        auxStock = new int*[tamPointer];
        for (int i = 0; i < numLibros; i++) {
            auxLibros[i] = libros[i];
            auxStock[i] = stock[i];
        }
        delete[] libros;
        delete[] stock;
        libros = auxLibros;
        stock = auxStock;
    }
}

void incrementarEspacios(char***& libros, int& numLibros, int& tamPointer) {
    char*** auxLibros;
    tamPointer += INCREMENTO;
    if (libros == NULL) {
        libros = new char**[tamPointer];
        libros[0] = NULL;
        numLibros++;
    } else {
        auxLibros = new char**[tamPointer];
        for (int i = 0; i < numLibros; i++) {
            auxLibros[i] = libros[i];
        }
        delete[] libros;
        libros = auxLibros;
    }
}


void imprimirLibros(char*** libros,int** stock) {
    for (int i = 0; libros[i] != NULL; i++) {
        cout << left << setw(10) << libros[i][0] << setw(50) << libros[i][1] << setw(40) << libros[i][2] 
             << setw(4) << stock[i][0] << setw(4) << stock[i][1] << endl;
    }
}


int* registrarPrestamos(int* codigoUs,char****& prestamos, char*** libros, int**& stock) {
    //25889071, HG2973,10/03/2017 --> codigo alumno, codigo libro, fecha del prestamo
    // stock tiene total libros, disponible
    int numAlumnos = 0;
    for (;codigoUs[numAlumnos] != -123; numAlumnos++);
    prestamos = new char***[numAlumnos+1];
    cout<<numAlumnos;
    int codigoAlumno;
    char *codigoLibro, *fecha;
    
    int* prestamosPorAlumno = new int[numAlumnos+1];
    int capacity[numAlumnos] = {0};
    
    for (int i = 0; i < numAlumnos; i++) {
        prestamosPorAlumno[i] = 0;
        prestamos[i] = NULL;
    }
    prestamosPorAlumno[numAlumnos] = -1;
    
    while(1) {
        if (cin.peek() == '\n') {
            cin.get();
            break;
        }
        cin >> codigoAlumno;
        cin.get();
        codigoLibro = leeCad(','); cin.get();
        fecha = leeCad('\n'); cin.get();
        
        int indiceAlumno = buscaPeMascota(codigoUs, codigoAlumno);
        if (indiceAlumno == -1) continue; // si no hay alumno, pasa
        
        char** aPrestium = new char*[2];
        aPrestium[0] = codigoLibro;
        aPrestium[1] = fecha;
        
        asignaPrestamo(prestamos[indiceAlumno], aPrestium, prestamosPorAlumno[indiceAlumno], capacity[indiceAlumno]);
        int indiceStock = buscaBienMascota(libros, aPrestium[0]);
        stock[indiceStock][1] -= 1; 
    }
    
    return prestamosPorAlumno;
}

int buscaBienMascota(char*** libros, char* searchIt) {
    int tomaTuPopo = 0;
    while(1) {
        if (strcmp(libros[tomaTuPopo][0], searchIt) == 0)
            return tomaTuPopo;
        tomaTuPopo++;
    }
}

void asignaPrestamo(char***& source, char** aPrestium, int& tamanhitus, int& aCapacitam) {
    if (tamanhitus == aCapacitam) 
        incrementarEspacios(source, tamanhitus, aCapacitam);
    source[tamanhitus-1] = aPrestium;
    source[tamanhitus] = NULL;
    tamanhitus++;
}

int buscaPeMascota(int* codigoUs, int codigoAlumno) {
    int tomaTuPopo = 0;
    for(; codigoUs[tomaTuPopo] != -123; tomaTuPopo++) {
        if (codigoUs[tomaTuPopo] == codigoAlumno)
            return tomaTuPopo;
    }
    return -1;
}

void imprimirPrestamos(int* codigoUs, char** nombresUs,char**** prestamos) {
    cout << left << setw(10) << "CODIGO" << setw(30) << "NOMBRE DE LA MASCOTA" << "PRESTAMOS" << endl;
    for (int i = 0; codigoUs[i] > 0; i++) {
        cout << left << setw(10) << codigoUs[i] << setw(50) << nombresUs[i]<<endl;
        if(prestamos[i]==NULL) cout<<"No solicito prestamo";
        else
            for(int j=0; prestamos[i][j]!=NULL; j++)
                cout<<prestamos[i][j][0]<<" - "<<prestamos[i][j][1]<<"    ";
        cout<<endl;
    }
    cout<<endl;
}