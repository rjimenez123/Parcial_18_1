#include <cstdlib>
#include "my_lib.h"
#include <iostream>
#include <iomanip>
#include <cstdio>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int *codigoUs, **stock, *prestamosPorAlumno; 
    char **nombreUs, ***libros, ****prestamos;
    leerUsuarios(codigoUs, nombreUs);
    imprimirUsuarios(codigoUs, nombreUs);
    leerLbros(libros, stock);
    imprimirLibros(libros, stock);
    prestamosPorAlumno = registrarPrestamos(codigoUs, prestamos, libros, stock);
    imprimirPrestamos(codigoUs, nombresUs, prestamos);   
    imprimirLibros(libros, stock);   
    
    return 0;
}

